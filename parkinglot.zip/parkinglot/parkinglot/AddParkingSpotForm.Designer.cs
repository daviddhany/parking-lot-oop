﻿namespace parkinglot
{
    partial class AddParkingSpotForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnAddSpot_Click = new Button();
            txtSpotNumber = new TextBox();
            txtSpotType = new ComboBox();
            label1 = new Label();
            label2 = new Label();
            SuspendLayout();
            // 
            // btnAddSpot_Click
            // 
            btnAddSpot_Click.Location = new Point(120, 159);
            btnAddSpot_Click.Name = "btnAddSpot_Click";
            btnAddSpot_Click.Size = new Size(127, 70);
            btnAddSpot_Click.TabIndex = 0;
            btnAddSpot_Click.Text = "Add spot";
            btnAddSpot_Click.UseVisualStyleBackColor = true;
            btnAddSpot_Click.Click += btnAddSpot_Click_Click;
            // 
            // txtSpotNumber
            // 
            txtSpotNumber.Location = new Point(96, 44);
            txtSpotNumber.Name = "txtSpotNumber";
            txtSpotNumber.Size = new Size(454, 27);
            txtSpotNumber.TabIndex = 1;
            txtSpotNumber.TextChanged += textBox1_TextChanged;
            // 
            // txtSpotType
            // 
            txtSpotType.FormattingEnabled = true;
            txtSpotType.Location = new Point(103, 99);
            txtSpotType.Name = "txtSpotType";
            txtSpotType.Size = new Size(447, 28);
            txtSpotType.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(34, 42);
            label1.Name = "label1";
            label1.Size = new Size(61, 20);
            label1.TabIndex = 3;
            label1.Text = "Spot no";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(43, 105);
            label2.Name = "label2";
            label2.Size = new Size(40, 20);
            label2.TabIndex = 4;
            label2.Text = "Type";
            // 
            // AddParkingSpotForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(800, 450);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtSpotType);
            Controls.Add(txtSpotNumber);
            Controls.Add(btnAddSpot_Click);
            FormBorderStyle = FormBorderStyle.None;
            Name = "AddParkingSpotForm";
            Text = "AddParkingSpotForm";
            Load += AddParkingSpotForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnAddSpot_Click;
        private TextBox txtSpotNumber;
        private ComboBox txtSpotType;
        private Label label1;
        private Label label2;
    }
}