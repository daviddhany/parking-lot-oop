﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace parkinglot
{
    public partial class AddParkingSpotForm : Form
    {
        private ParkingLot parkingLot;
        public AddParkingSpotForm(ParkingLot parkingLot)
        {
            InitializeComponent();
            this.parkingLot = parkingLot;

        }

        private void AddParkingSpotForm_Load(object sender, EventArgs e)
        {

        }

        private void btnAddSpot_Click_Click(object sender, EventArgs e)
        {
            var spotNumber = int.Parse(txtSpotNumber.Text);
            var spotType = txtSpotType.Text;

            var parkingSpot = new ParkingSpot(spotNumber, spotType);
            parkingLot.AddParkingSpot(parkingSpot, spotNumber);
            MessageBox.Show("Parking spot added.");
            Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
