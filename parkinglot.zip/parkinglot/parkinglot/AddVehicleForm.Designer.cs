﻿namespace parkinglot
{
    partial class AddVehicleForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtLicensePlate = new TextBox();
            comboBox1 = new ComboBox();
            txtNumDoors = new TextBox();
            chkHasSidecar = new CheckBox();
            btnAddCar = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            btnAddMotorcycle = new Button();
            SuspendLayout();
            // 
            // txtLicensePlate
            // 
            txtLicensePlate.Location = new Point(124, 29);
            txtLicensePlate.Name = "txtLicensePlate";
            txtLicensePlate.Size = new Size(215, 27);
            txtLicensePlate.TabIndex = 0;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Car", "Motorcycle" });
            comboBox1.Location = new Point(124, 84);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(215, 28);
            comboBox1.TabIndex = 1;
            // 
            // txtNumDoors
            // 
            txtNumDoors.Location = new Point(124, 158);
            txtNumDoors.Name = "txtNumDoors";
            txtNumDoors.Size = new Size(215, 27);
            txtNumDoors.TabIndex = 2;
            // 
            // chkHasSidecar
            // 
            chkHasSidecar.AutoSize = true;
            chkHasSidecar.Location = new Point(151, 317);
            chkHasSidecar.Name = "chkHasSidecar";
            chkHasSidecar.Size = new Size(18, 17);
            chkHasSidecar.TabIndex = 3;
            chkHasSidecar.UseVisualStyleBackColor = true;
            // 
            // btnAddCar
            // 
            btnAddCar.Location = new Point(440, 126);
            btnAddCar.Name = "btnAddCar";
            btnAddCar.Size = new Size(168, 55);
            btnAddCar.TabIndex = 4;
            btnAddCar.Text = "Add vehicle";
            btnAddCar.UseVisualStyleBackColor = true;
            btnAddCar.Click += btnAddCar_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(20, 29);
            label1.Name = "label1";
            label1.Size = new Size(98, 20);
            label1.TabIndex = 5;
            label1.Text = "plate number";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(14, 84);
            label2.Name = "label2";
            label2.Size = new Size(106, 20);
            label2.TabIndex = 6;
            label2.Text = "type of vehicle";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(22, 161);
            label3.Name = "label3";
            label3.Size = new Size(86, 20);
            label3.TabIndex = 7;
            label3.Text = "no of doors";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(38, 317);
            label4.Name = "label4";
            label4.Size = new Size(70, 20);
            label4.TabIndex = 8;
            label4.Text = "sidecar??";
            // 
            // btnAddMotorcycle
            // 
            btnAddMotorcycle.Location = new Point(333, 300);
            btnAddMotorcycle.Name = "btnAddMotorcycle";
            btnAddMotorcycle.Size = new Size(168, 55);
            btnAddMotorcycle.TabIndex = 4;
            btnAddMotorcycle.Text = "add motorcycle";
            btnAddMotorcycle.UseVisualStyleBackColor = true;
            btnAddMotorcycle.Click += btnAddCar_Click;
            // 
            // AddVehicleForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(800, 450);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnAddMotorcycle);
            Controls.Add(btnAddCar);
            Controls.Add(chkHasSidecar);
            Controls.Add(txtNumDoors);
            Controls.Add(comboBox1);
            Controls.Add(txtLicensePlate);
            FormBorderStyle = FormBorderStyle.None;
            Name = "AddVehicleForm";
            Text = "a";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtLicensePlate;
        private ComboBox comboBox1;
        private TextBox txtNumDoors;
        private CheckBox chkHasSidecar;
        private Button btnAddCar;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Button btnAddMotorcycle;
    }
}