﻿using System;
using System.Windows.Forms;

namespace parkinglot
{
    public partial class AddVehicleForm : Form
    {
        private ParkingLot parkingLot;

        public AddVehicleForm(ParkingLot parkingLot)
        {
            InitializeComponent();
            this.parkingLot = parkingLot;
        }

        private void btnAddCar_Click(object sender, EventArgs e)
        {
            string licensePlate = txtLicensePlate.Text;
            if (string.IsNullOrWhiteSpace(licensePlate))
            {
                MessageBox.Show("Please enter a valid license plate number.");
                return;
            }

            int numDoors;
            if (!int.TryParse(txtNumDoors.Text, out numDoors))
            {
                MessageBox.Show("Please enter a valid number of doors.");
                return;
            }

            var car = new Car(licensePlate, numDoors);
            parkingLot.ParkVehicle(car);
            MessageBox.Show("Car added and parked.");
            Close();
        }

        private void btnAddMotorcycle_Click(object sender, EventArgs e)
        {
            string licensePlate = txtLicensePlate.Text;
            if (string.IsNullOrWhiteSpace(licensePlate))
            {
                MessageBox.Show("Please enter a valid license plate number.");
                return;
            }

            var motorcycle = new Motorcycle(licensePlate, chkHasSidecar.Checked);
            parkingLot.ParkVehicle(motorcycle);
            MessageBox.Show("Motorcycle added and parked.");
            Close();
        }
    }
}
