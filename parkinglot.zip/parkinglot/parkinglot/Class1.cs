﻿using System;
public abstract class Vehicle
{
    public string LicensePlate { get; set; }
    public string VehicleType { get; set; }

    protected Vehicle(string licensePlate, string vehicleType)
    {
        LicensePlate = licensePlate;
        VehicleType = vehicleType;
    }

    public abstract void Park();
    public abstract void Unpark();
}
public class Car : Vehicle
{
    public int NumDoors { get; set; }
    public bool IsElectric { get; set; }

    public Car(string licensePlate, int numDoors)
        : base(licensePlate, "Car")
    {
        NumDoors = numDoors;
    }

    public override void Park()
    {
        Console.WriteLine("Car parked.");
    }

    public override void Unpark()
    {
        Console.WriteLine("Car unparked.");
    }
}
public class Motorcycle : Vehicle
{
    public bool HasSidecar { get; set; }

    public Motorcycle(string licensePlate, bool hasSidecar)
        : base(licensePlate, "Motorcycle")
    {
        HasSidecar = hasSidecar;
    }

    public override void Park()
    {
        Console.WriteLine("Motorcycle parked.");
    }

    public override void Unpark()
    {
        Console.WriteLine("Motorcycle unparked.");
    }
}
public class ParkingSpot
{
    public int SpotNumber { get; set; }
    public string SpotType { get; set; }
    public bool IsOccupied { get; set; }
    public Vehicle Vehicle { get; set; }

    public ParkingSpot(int spotNumber, string spotType)
    {
        SpotNumber = spotNumber;
        SpotType = spotType;
        IsOccupied = false;
        Vehicle = null;
    }

    public void AssignVehicle(Vehicle vehicle)
    {
        Vehicle = vehicle;
        IsOccupied = true;
    }

    public void RemoveVehicle()
    {
        Vehicle = null;
        IsOccupied = false;
    }
}

public class ParkingLot
{
    public string Name { get; set; }
    public string Location { get; set; }
    private ParkingSpot[] parkingSpots;

    public int TotalSpots => parkingSpots.Length;
    public int AvailableSpots
    {
        get
        {
            int count = 0;
            foreach (var spot in parkingSpots)
            {
                if (!spot.IsOccupied)
                {
                    count++;
                }
            }
            return count;
        }
    }

    public ParkingLot(string name, string location, int capacity)
    {
        Name = name;
        Location = location;
        parkingSpots = new ParkingSpot[capacity];
        for (int i = 0; i < capacity; i++)
        {
            parkingSpots[i] = new ParkingSpot(i, i % 2 == 0 ? "Car" : "Motorcycle");
        }
    }

    public void AddParkingSpot(ParkingSpot spot, int index)
    {
        if (index >= 0 && index < parkingSpots.Length && parkingSpots[index] == null)
        {
            parkingSpots[index] = spot;
        }
    }

    public void RemoveParkingSpot(int spotNumber)
    {
        if (spotNumber >= 0 && spotNumber < parkingSpots.Length && parkingSpots[spotNumber] != null)
        {
            parkingSpots[spotNumber] = null;
        }
    }

    public void ParkVehicle(Vehicle vehicle)
    {
        foreach (var spot in parkingSpots)
        {
            if (spot != null && !spot.IsOccupied && spot.SpotType == vehicle.VehicleType)
            {
                spot.AssignVehicle(vehicle);
                vehicle.Park();
                break;
            }
        }
    }

    public void UnparkVehicle(string licensePlate)
    {
        foreach (var spot in parkingSpots)
        {
            if (spot != null && spot.IsOccupied && spot.Vehicle.LicensePlate == licensePlate)
            {
                spot.Vehicle.Unpark();
                spot.RemoveVehicle();
                break;
            }
        }
    }
}

