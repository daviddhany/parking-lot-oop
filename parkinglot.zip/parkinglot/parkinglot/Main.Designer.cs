﻿namespace parkinglot
{
    partial class Main
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblTotalSpots = new Label();
            lblAvailableSpots = new Label();
            btnAddVehicle = new Button();
            btnRemoveVehicle = new Button();
            btnAddParkingSpot = new Button();
            btnRemoveParkingSpot = new Button();
            SuspendLayout();
            // 
            // lblTotalSpots
            // 
            lblTotalSpots.AutoSize = true;
            lblTotalSpots.Location = new Point(12, 47);
            lblTotalSpots.Name = "lblTotalSpots";
            lblTotalSpots.Size = new Size(83, 20);
            lblTotalSpots.TabIndex = 0;
            lblTotalSpots.Text = "Total Spots";
            // 
            // lblAvailableSpots
            // 
            lblAvailableSpots.AutoSize = true;
            lblAvailableSpots.Location = new Point(12, 121);
            lblAvailableSpots.Name = "lblAvailableSpots";
            lblAvailableSpots.Size = new Size(112, 20);
            lblAvailableSpots.TabIndex = 1;
            lblAvailableSpots.Text = "Available Spots";
            // 
            // btnAddVehicle
            // 
            btnAddVehicle.Location = new Point(12, 203);
            btnAddVehicle.Name = "btnAddVehicle";
            btnAddVehicle.Size = new Size(175, 32);
            btnAddVehicle.TabIndex = 2;
            btnAddVehicle.Text = "Add Vehicle";
            btnAddVehicle.UseVisualStyleBackColor = true;
            btnAddVehicle.Click += btnAddVehicle_Click;
            // 
            // btnRemoveVehicle
            // 
            btnRemoveVehicle.Location = new Point(18, 259);
            btnRemoveVehicle.Name = "btnRemoveVehicle";
            btnRemoveVehicle.Size = new Size(169, 29);
            btnRemoveVehicle.TabIndex = 3;
            btnRemoveVehicle.Text = "remove vehicle";
            btnRemoveVehicle.UseVisualStyleBackColor = true;
            btnRemoveVehicle.Click += btnRemoveVehicle_Click;
            // 
            // btnAddParkingSpot
            // 
            btnAddParkingSpot.Location = new Point(18, 325);
            btnAddParkingSpot.Name = "btnAddParkingSpot";
            btnAddParkingSpot.Size = new Size(169, 29);
            btnAddParkingSpot.TabIndex = 4;
            btnAddParkingSpot.Text = "Add spot";
            btnAddParkingSpot.UseVisualStyleBackColor = true;
            btnAddParkingSpot.Click += btnAddParkingSpot_Click;
            // 
            // btnRemoveParkingSpot
            // 
            btnRemoveParkingSpot.Location = new Point(18, 397);
            btnRemoveParkingSpot.Name = "btnRemoveParkingSpot";
            btnRemoveParkingSpot.Size = new Size(169, 29);
            btnRemoveParkingSpot.TabIndex = 5;
            btnRemoveParkingSpot.Text = "remove spot";
            btnRemoveParkingSpot.UseVisualStyleBackColor = true;
            btnRemoveParkingSpot.Click += btnRemoveParkingSpot_Click;
            // 
            // Main
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(905, 530);
            Controls.Add(btnRemoveParkingSpot);
            Controls.Add(btnAddParkingSpot);
            Controls.Add(btnRemoveVehicle);
            Controls.Add(btnAddVehicle);
            Controls.Add(lblAvailableSpots);
            Controls.Add(lblTotalSpots);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Main";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblTotalSpots;
        private Label lblAvailableSpots;
        private Button btnAddVehicle;
        private Button btnRemoveVehicle;
        private Button btnAddParkingSpot;
        private Button btnRemoveParkingSpot;
    }
}
