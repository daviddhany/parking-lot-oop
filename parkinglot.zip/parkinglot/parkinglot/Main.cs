namespace parkinglot
{
    public partial class Main : Form
    {
        private ParkingLot parkingLot;

        public Main()
        {
            InitializeComponent();
            parkingLot = new ParkingLot("Main Lot", "123 Main St", 100);
        }
        private void UpdateStatus()
        {
            lblTotalSpots.Text = $"Total Spots: {parkingLot.TotalSpots}";
            lblAvailableSpots.Text = $"Available Spots: {parkingLot.AvailableSpots}";
        }

        private void totalspots_TextChanged(object sender, EventArgs e)
        {

        }

        private void availablespots_TextChanged(object sender, EventArgs e)
        {


        }

        private void btnAddVehicle_Click(object sender, EventArgs e)
        {
            var addVehicleForm = new AddVehicleForm(parkingLot);
            addVehicleForm.ShowDialog();
            UpdateStatus();

        }

        private void btnRemoveVehicle_Click(object sender, EventArgs e)
        {
            var removeVehicleForm = new RemoveVehicleForm(parkingLot);
            removeVehicleForm.ShowDialog();
            UpdateStatus();

        }

        private void btnAddParkingSpot_Click(object sender, EventArgs e)
        {
            var addParkingSpotForm = new AddParkingSpotForm(parkingLot);
            addParkingSpotForm.ShowDialog();
            UpdateStatus();

        }

        private void btnRemoveParkingSpot_Click(object sender, EventArgs e)
        {
            var removeParkingSpotForm = new RemoveParkingSpotForm(parkingLot);
            removeParkingSpotForm.ShowDialog();
            UpdateStatus();
        }
    }
}
