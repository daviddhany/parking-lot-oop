﻿namespace parkinglot
{
    partial class RemoveParkingSpotForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnRemoveSpo = new Button();
            txtSpotNumber = new TextBox();
            label1 = new Label();
            SuspendLayout();
            // 
            // btnRemoveSpo
            // 
            btnRemoveSpo.Location = new Point(196, 146);
            btnRemoveSpo.Name = "btnRemoveSpo";
            btnRemoveSpo.Size = new Size(94, 29);
            btnRemoveSpo.TabIndex = 0;
            btnRemoveSpo.Text = "remove";
            btnRemoveSpo.UseVisualStyleBackColor = true;
            btnRemoveSpo.Click += btnRemoveSpo_Click;
            // 
            // txtSpotNumber
            // 
            txtSpotNumber.Location = new Point(157, 83);
            txtSpotNumber.Name = "txtSpotNumber";
            txtSpotNumber.Size = new Size(163, 27);
            txtSpotNumber.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(31, 86);
            label1.Name = "label1";
            label1.Size = new Size(59, 20);
            label1.TabIndex = 2;
            label1.Text = "spot no";
            // 
            // RemoveParkingSpotForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(800, 450);
            Controls.Add(label1);
            Controls.Add(txtSpotNumber);
            Controls.Add(btnRemoveSpo);
            FormBorderStyle = FormBorderStyle.None;
            Name = "RemoveParkingSpotForm";
            Text = "RemoveParkingSpotForm";
            Load += RemoveParkingSpotForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnRemoveSpo;
        private TextBox txtSpotNumber;
        private Label label1;
    }
}