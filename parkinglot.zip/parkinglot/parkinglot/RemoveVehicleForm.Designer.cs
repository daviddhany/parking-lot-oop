﻿namespace parkinglot
{
    partial class RemoveVehicleForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnRemoveVehicle = new Button();
            txtLicensePlate = new TextBox();
            label1 = new Label();
            SuspendLayout();
            // 
            // btnRemoveVehicle
            // 
            btnRemoveVehicle.Location = new Point(203, 258);
            btnRemoveVehicle.Name = "btnRemoveVehicle";
            btnRemoveVehicle.Size = new Size(94, 29);
            btnRemoveVehicle.TabIndex = 0;
            btnRemoveVehicle.Text = "Remove";
            btnRemoveVehicle.UseVisualStyleBackColor = true;
            btnRemoveVehicle.Click += btnRemoveVehicle_Click;
            // 
            // txtLicensePlate
            // 
            txtLicensePlate.Location = new Point(178, 62);
            txtLicensePlate.Name = "txtLicensePlate";
            txtLicensePlate.Size = new Size(115, 27);
            txtLicensePlate.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(22, 80);
            label1.Name = "label1";
            label1.Size = new Size(75, 20);
            label1.TabIndex = 2;
            label1.Text = "license no";
            // 
            // RemoveVehicleForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(800, 450);
            Controls.Add(label1);
            Controls.Add(txtLicensePlate);
            Controls.Add(btnRemoveVehicle);
            FormBorderStyle = FormBorderStyle.None;
            Name = "RemoveVehicleForm";
            Text = "RemoveVehicleForm";
            Load += RemoveVehicleForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnRemoveVehicle;
        private TextBox txtLicensePlate;
        private Label label1;
    }
}