﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace parkinglot
{
    public partial class RemoveVehicleForm : Form
    {
        private ParkingLot parkingLot;

        public RemoveVehicleForm(ParkingLot parkingLot)
        {
            InitializeComponent();
            this.parkingLot = parkingLot;

        }

        private void btnRemoveVehicle_Click(object sender, EventArgs e)
        {
            var licensePlate = txtLicensePlate.Text;
            parkingLot.UnparkVehicle(licensePlate);
            MessageBox.Show("Vehicle removed.");
            Close();
        }

        private void RemoveVehicleForm_Load(object sender, EventArgs e)
        {

        }
    }
}
